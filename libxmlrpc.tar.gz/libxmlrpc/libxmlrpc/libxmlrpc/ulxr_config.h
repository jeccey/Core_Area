/* Edit this file with care. It is automatically generated from config.h. */
#define ULXMLRPCPP_VERSION "1.7.5"
#define ULXR_PACKAGE "ulxmlrpcpp"
/* #undef ULXR_UNICODE */
#define ULXR_UNICODE_ONLY_HELPERS 1
#define ULXR_INCLUDE_SSL_STUFF 1
#define ULXR_MULTITHREADED 1
/* Define to re-use a server socket (saves time while debugging). */
/* #undef ULXR_REUSE_SOCKET */

/* define if you want to omit tcp/ip and http stuff. */
/* #undef ULXR_OMIT_TCP_STUFF */

/* Version number of package as long int */
#define ULXR_VERSION_NUMBER "0x00010705"
#define ULXR_VERSION "1.7.5"

